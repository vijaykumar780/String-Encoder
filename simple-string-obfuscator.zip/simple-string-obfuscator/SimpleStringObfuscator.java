import java.io.PrintStream;
import java.util.Random;

public class SimpleStringObfuscator {
    public static void main(String[] args) {
        args = new String[10];
        args[0] = "V{P4SFb5_^OsMQ[8QbUjo&5!c,saGghEvM]Vj'@TI=9#Bwqxiw";
        if (args != null && args.length > 0) {
            Random r = new Random(System.currentTimeMillis());
            byte[] b = args[0].getBytes();
            int c = b.length;
            PrintStream o = System.out;

            o.print("(new Object() {");
            o.print("int t;");
            o.print("public String toString() {");
            o.print("byte[] buf = new byte[");
            o.print(c);
            o.print("];");

            for (int i = 0; i < c; ++i) {
                int t = r.nextInt();
                int f = r.nextInt(24) + 1;

                t = (t & ~(0xff << f)) | (b[i] << f);

                o.print("t = ");
                o.print(t);
                o.print(";");
                o.print("buf[");
                o.print(i);
                o.print("] = (byte) (t >>> ");
                o.print(f);
                o.print(");");
            }

            o.print("return new String(buf);");
            o.print("}}.toString())");
            o.println();
        }
        //System.out.println((new Object() {int t;public String toString() {byte[] buf = new byte[5];t = 875144045;buf[0] = (byte) (t >>> 23);t = 650849820;buf[1] = (byte) (t >>> 17);t = -1681598058;buf[2] = (byte) (t >>> 9);t = -1956360070;buf[3] = (byte) (t >>> 19);t = 932342400;buf[4] = (byte) (t >>> 23);return new String(buf);}}.toString()));
    }
}
